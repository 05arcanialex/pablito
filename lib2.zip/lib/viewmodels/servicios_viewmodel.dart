
import 'package:flutter/material.dart';
import '../models/database_helper.dart';

class ServiciosViewModel extends ChangeNotifier {
  final _db = DatabaseHelper.instance;

  bool _loading = false;
  List<Map<String, Object?>> _rows = [];
  String _filtroCategoria = 'TODOS';

  bool get loading => _loading;
  List<Map<String, Object?>> get rows => _rows;
  String get filtroCategoria => _filtroCategoria;

  Future<void> load() async {
    _loading = true;
    notifyListeners();

    const sql = '''
      SELECT rst.cod_ser_taller,
             rst.fecha_ingreso,
             rst.fecha_salida,
             rst.observaciones,
             v.placas AS vehiculo,
             p.nombre || ' ' || p.apellidos AS cliente,
             (SELECT GROUP_CONCAT(tt.descripcion, ', ')
                FROM reg_serv_taller_tipo_trabajo rtt
                JOIN tipo_trabajo tt ON tt.cod_tipo_trabajo = rtt.cod_tipo_trabajo
               WHERE rtt.cod_ser_taller = rst.cod_ser_taller) AS tipos,
             COALESCE((SELECT SUM(rtt.costo) FROM reg_serv_taller_tipo_trabajo rtt
                       WHERE rtt.cod_ser_taller = rst.cod_ser_taller), 0) AS total_aprox
        FROM registro_servicio_taller rst
        JOIN vehiculo v   ON v.cod_vehiculo = rst.cod_vehiculo
        JOIN cliente c    ON c.cod_clinte = v.cod_cliente
        JOIN persona p    ON p.cod_persona = c.cod_persona
       ORDER BY rst.cod_ser_taller DESC
    ''';

    _rows = await _db.rawQuery(sql);
    _loading = false;
    notifyListeners();
  }

  void setFiltro(String value) {
    _filtroCategoria = value;
    notifyListeners();
  }

  List<Map<String, Object?>> get filtered {
    if (_filtroCategoria == 'TODOS') return _rows;
    return _rows.where((e) {
      final tipos = (e['tipos'] as String?) ?? '';
      return tipos.toUpperCase().contains(_filtroCategoria.toUpperCase());
    }).toList();
  }

  Future<bool> deleteCabecera(int codSerTaller) async {
    await _db.rawDelete('DELETE FROM reg_serv_taller_tipo_trabajo WHERE cod_ser_taller = ?', [codSerTaller]);
    final n = await _db.rawDelete('DELETE FROM registro_servicio_taller WHERE cod_ser_taller = ?', [codSerTaller]);
    await load();
    return n > 0;
  }

  Future<bool> updateObservaciones({required int codSerTaller, required String observ}) async {
    final n = await _db.rawUpdate(
      'UPDATE registro_servicio_taller SET observaciones = ? WHERE cod_ser_taller = ?',
      [observ, codSerTaller],
    );
    await load();
    return n > 0;
  }
}
