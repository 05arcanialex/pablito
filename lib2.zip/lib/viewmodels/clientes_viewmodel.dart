
import 'package:flutter/material.dart';
import '../models/database_helper.dart';

class ClientesViewModel extends ChangeNotifier {
  final _db = DatabaseHelper.instance;
  bool _loading = false;
  List<Map<String, Object?>> _rows = [];

  bool get loading => _loading;
  List<Map<String, Object?>> get rows => _rows;

  Future<void> load() async {
    _loading = true;
    notifyListeners();
    const sql = '''
      SELECT c.cod_clinte,
             p.nombre,
             p.apellidos,
             p.telefono,
             p.email
        FROM cliente c
        JOIN persona p ON p.cod_persona = c.cod_persona
       ORDER BY p.apellidos, p.nombre
    ''';
    _rows = await _db.rawQuery(sql);
    _loading = false;
    notifyListeners();
  }
}
