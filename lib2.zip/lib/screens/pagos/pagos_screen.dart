
import 'package:flutter/material.dart';
class PagosScreen extends StatelessWidget {
  const PagosScreen({super.key});
  @override
  Widget build(BuildContext context) {
    return Center(child: Text('PagosScreen'));
  }
}
