
import 'package:flutter/material.dart';
class HistorialScreen extends StatelessWidget {
  const HistorialScreen({super.key});
  @override
  Widget build(BuildContext context) {
    return Center(child: Text('HistorialScreen'));
  }
}
