// lib/screens/servicios/servicios_screen.dart
import 'package:flutter/material.dart';
import '../../utils/constants.dart';

class ServiciosScreen extends StatefulWidget {
  const ServiciosScreen({super.key});

  @override
  State<ServiciosScreen> createState() => _ServiciosScreenState();
}

class _ServiciosScreenState extends State<ServiciosScreen> {
  // Categorías del combo
  static const String catTodos = 'TODOS';
  static const String catDiag = 'DIAGNÓSTICO';
  static const String catMant = 'MANTENIMIENTO';
  static const String catRep  = 'REPARACIONES EN GENERAL';
  static const String catProg = 'PROGRAMACIÓN DE MÓDULOS';

  final List<String> _categorias = const [
    catTodos, catDiag, catMant, catRep, catProg,
  ];

  String _categoriaSeleccionada = catTodos;

  // MOCK: Datos de ejemplo (hasta conectar con BD / ViewModel)
  final List<_ServicioRow> _rows = [
    _ServicioRow(
      id: 1001,
      fecha: DateTime(2025, 1, 10),
      cliente: 'JUAN PÉREZ',
      vehiculo: 'TOYOTA COROLLA',
      tipo: catDiag,
      costo: 120.0,
      estado: 'EN CURSO',
    ),
    _ServicioRow(
      id: 1002,
      fecha: DateTime(2025, 1, 11),
      cliente: 'MARÍA LÓPEZ',
      vehiculo: 'NISSAN VERSA',
      tipo: catMant,
      costo: 250.0,
      estado: 'TERMINADO',
    ),
    _ServicioRow(
      id: 1003,
      fecha: DateTime(2025, 1, 12),
      cliente: 'CARLOS G.',
      vehiculo: 'SUZUKI SWIFT',
      tipo: catRep,
      costo: 480.5,
      estado: 'EN ESPERA',
    ),
    _ServicioRow(
      id: 1004,
      fecha: DateTime(2025, 1, 12),
      cliente: 'ANA M.',
      vehiculo: 'KIA RIO',
      tipo: catProg,
      costo: 350.0,
      estado: 'TERMINADO',
    ),
  ];

  List<_ServicioRow> get _filtered {
    if (_categoriaSeleccionada == catTodos) return _rows;
    return _rows.where((e) => e.tipo == _categoriaSeleccionada).toList();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      color: AppColors.background,
      child: Column(
        children: [
          _buildToolbarResponsive(),
          const SizedBox(height: AppSpacing.medium),

          // —— TABLA SCROLLABLE (H Y V) —— 
          Expanded(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: AppSpacing.large),
              child: Container(
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(AppRadius.medium),
                  boxShadow: const [
                    BoxShadow(
                      color: Colors.black12,
                      blurRadius: 6,
                      offset: Offset(0, 2),
                    ),
                  ],
                ),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(AppRadius.medium),
                  child: _buildTable(),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ──────────────────────────────────────────────
  // TOOLBAR RESPONSIVE
  // ──────────────────────────────────────────────
  Widget _buildToolbarResponsive() {
    return LayoutBuilder(
      builder: (context, constraints) {
        final isNarrow = constraints.maxWidth < 720; // breakpoint

        final titleWidget = Text(
          'SERVICIOS',
          style: AppTextStyles.heading2.copyWith(
            color: AppColors.primary,
            fontWeight: FontWeight.w800,
            letterSpacing: 0.5,
          ),
        );

        final dropdown = Container(
          padding: const EdgeInsets.symmetric(horizontal: 12),
          decoration: BoxDecoration(
            color: AppColors.backgroundVariant,
            borderRadius: BorderRadius.circular(AppRadius.small),
          ),
          child: DropdownButtonHideUnderline(
            child: DropdownButton<String>(
              value: _categoriaSeleccionada,
              isDense: true,
              items: _categorias
                  .map((c) => DropdownMenuItem(
                        value: c,
                        child: Text(
                          c,
                          overflow: TextOverflow.ellipsis,
                          style: AppTextStyles.body.copyWith(
                            color: AppColors.textPrimary,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ))
                  .toList(),
              onChanged: (v) => setState(() => _categoriaSeleccionada = v!),
            ),
          ),
        );

        final auxilioBtn = FilledButton.icon(
          onPressed: _onAuxilio,
          icon: const Icon(Icons.sos),
          label: const Text('AUXILIO'),
          style: FilledButton.styleFrom(
            backgroundColor: AppColors.accent,
            foregroundColor: Colors.white,
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(AppRadius.small),
            ),
          ),
        );

        return Container(
          padding: const EdgeInsets.symmetric(
            horizontal: AppSpacing.large,
            vertical: AppSpacing.medium,
          ),
          decoration: const BoxDecoration(
            color: Colors.white,
            boxShadow: [
              BoxShadow(color: Colors.black12, blurRadius: 6, offset: Offset(0, 2)),
            ],
          ),
          child: isNarrow
              ? Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    titleWidget,
                    const SizedBox(height: AppSpacing.small),
                    Wrap(
                      spacing: AppSpacing.medium,
                      runSpacing: AppSpacing.small,
                      crossAxisAlignment: WrapCrossAlignment.center,
                      children: [
                        ConstrainedBox(
                          constraints: BoxConstraints(
                            maxWidth: constraints.maxWidth - 2 * AppSpacing.large,
                            minWidth: 180,
                          ),
                          child: dropdown,
                        ),
                        auxilioBtn,
                      ],
                    ),
                  ],
                )
              : Row(
                  children: [
                    Expanded(child: titleWidget),
                    ConstrainedBox(
                      constraints: const BoxConstraints(maxWidth: 360),
                      child: dropdown,
                    ),
                    const SizedBox(width: AppSpacing.medium),
                    auxilioBtn,
                  ],
                ),
        );
      },
    );
  }

  // ──────────────────────────────────────────────
  // TABLA CON CRUD
  // ──────────────────────────────────────────────
  Widget _buildTable() {
    final rows = _filtered;

    return Scrollbar(
      thumbVisibility: true,
      child: SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        child: ConstrainedBox(
          constraints: const BoxConstraints(minWidth: 820),
          child: SingleChildScrollView(
            child: DataTable(
              headingRowColor:
                  MaterialStateProperty.all(AppColors.primary.withOpacity(0.08)),
              dataRowMinHeight: 56,
              dataRowMaxHeight: 64,
              columns: const [
                DataColumn(label: _HeaderText('CÓDIGO')),
                DataColumn(label: _HeaderText('FECHA')),
                DataColumn(label: _HeaderText('CLIENTE')),
                DataColumn(label: _HeaderText('VEHÍCULO')),
                DataColumn(label: _HeaderText('TIPO')),
                DataColumn(label: _HeaderText('COSTO (BS)')),
                DataColumn(label: _HeaderText('ESTADO')),
                DataColumn(label: _HeaderText('ACCIONES')),
              ],
              rows: rows.map((e) => _buildRow(e)).toList(),
            ),
          ),
        ),
      ),
    );
  }

  DataRow _buildRow(_ServicioRow e) {
    return DataRow(
      cells: [
        DataCell(Text('${e.id}')),
        DataCell(Text(_fmtDate(e.fecha))),
        DataCell(Text(e.cliente)),
        DataCell(Text(e.vehiculo)),
        DataCell(_TipoBadge(texto: e.tipo)),
        DataCell(Text(e.costo.toStringAsFixed(2))),
        DataCell(Text(e.estado)),
        DataCell(
          Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              IconButton(
                tooltip: 'VER',
                icon: const Icon(Icons.visibility, color: AppColors.textSecondary),
                onPressed: () => _onVer(e),
              ),
              IconButton(
                tooltip: 'EDITAR',
                icon: const Icon(Icons.edit, color: AppColors.primary),
                onPressed: () => _onEditar(e),
              ),
              IconButton(
                tooltip: 'ELIMINAR',
                icon: const Icon(Icons.delete_forever, color: AppColors.accent),
                onPressed: () => _onEliminar(e),
              ),
            ],
          ),
        ),
      ],
    );
  }

  // ───────── ACCIONES CRUD (MOCK UI) ─────────

  void _onVer(_ServicioRow e) {
    showModalBottomSheet(
      context: context,
      showDragHandle: true,
      isScrollControlled: true,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (_) => Padding(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text('DETALLE DEL SERVICIO #${e.id}',
                style: AppTextStyles.heading2.copyWith(
                  color: AppColors.primary,
                  fontWeight: FontWeight.w800,
                )),
            const SizedBox(height: 12),
            _detailRow('FECHA', _fmtDate(e.fecha)),
            _detailRow('CLIENTE', e.cliente),
            _detailRow('VEHÍCULO', e.vehiculo),
            _detailRow('TIPO', e.tipo),
            _detailRow('COSTO (BS)', e.costo.toStringAsFixed(2)),
            _detailRow('ESTADO', e.estado),
            const SizedBox(height: 12),
            FilledButton.icon(
              onPressed: () => Navigator.pop(context),
              icon: const Icon(Icons.check),
              label: const Text('CERRAR'),
            ),
            const SizedBox(height: 8),
          ],
        ),
      ),
    );
  }

  void _onEditar(_ServicioRow e) async {
    final idController = TextEditingController(text: '${e.id}');
    final costoController = TextEditingController(text: e.costo.toStringAsFixed(2));
    String estadoTmp = e.estado;

    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('EDITAR SERVICIO'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextFormField(
              controller: idController,
              enabled: false,
              decoration: const InputDecoration(
                labelText: 'CÓDIGO',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: AppSpacing.medium),
            TextFormField(
              controller: costoController,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(
                labelText: 'COSTO (BS)',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: AppSpacing.medium),
            DropdownButtonFormField<String>(
              value: estadoTmp,
              items: const [
                DropdownMenuItem(value: 'EN CURSO', child: Text('EN CURSO')),
                DropdownMenuItem(value: 'EN ESPERA', child: Text('EN ESPERA')),
                DropdownMenuItem(value: 'TERMINADO', child: Text('TERMINADO')),
              ],
              onChanged: (v) => estadoTmp = v ?? e.estado,
              decoration: const InputDecoration(
                labelText: 'ESTADO',
                border: OutlineInputBorder(),
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('CANCELAR'),
          ),
          FilledButton.icon(
            icon: const Icon(Icons.save),
            label: const Text('GUARDAR'),
            onPressed: () => Navigator.pop(context, true),
          ),
        ],
      ),
    );

    if (ok == true) {
      setState(() {
        final idx = _rows.indexWhere((r) => r.id == e.id);
        if (idx >= 0) {
          _rows[idx] = _rows[idx].copyWith(
            costo: double.tryParse(costoController.text.replaceAll(',', '.')) ?? e.costo,
            estado: estadoTmp,
          );
        }
      });
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('SERVICIO #${e.id} ACTUALIZADO')),
      );
    }
  }

  void _onEliminar(_ServicioRow e) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('ELIMINAR SERVICIO'),
        content: Text('¿DESEAS ELIMINAR EL SERVICIO #${e.id}?'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('CANCELAR')),
          FilledButton.tonalIcon(
            icon: const Icon(Icons.delete),
            label: const Text('ELIMINAR'),
            style: FilledButton.styleFrom(
              backgroundColor: AppColors.accent,
              foregroundColor: Colors.white,
            ),
            onPressed: () => Navigator.pop(context, true),
          ),
        ],
      ),
    );
    if (ok == true) {
      setState(() => _rows.removeWhere((r) => r.id == e.id));
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('SERVICIO #${e.id} ELIMINADO')),
      );
    }
  }

  void _onAuxilio() {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('SOLICITUD DE AUXILIO ENVIADA')),
    );
  }

  String _fmtDate(DateTime d) {
    final m = d.month.toString().padLeft(2, '0');
    final day = d.day.toString().padLeft(2, '0');
    return '${d.year}-$m-$day';
  }

  Widget _detailRow(String k, String v) {
    return Container(
      margin: const EdgeInsets.symmetric(vertical: 6),
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      decoration: BoxDecoration(
        color: AppColors.background,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: AppColors.backgroundVariant, width: 1),
      ),
      child: Row(
        children: [
          SizedBox(
            width: 140,
            child: Text(
              k,
              style: AppTextStyles.body.copyWith(
                color: AppColors.textPrimary,
                fontWeight: FontWeight.w700,
              ),
            ),
          ),
          Expanded(
            child: Text(
              v,
              textAlign: TextAlign.right,
              style: AppTextStyles.body.copyWith(
                color: AppColors.textPrimary,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

/// Modelo simple para la tabla (UI)
class _ServicioRow {
  final int id;
  final DateTime fecha;
  final String cliente;
  final String vehiculo;
  final String tipo;
  final double costo;
  final String estado;

  _ServicioRow({
    required this.id,
    required this.fecha,
    required this.cliente,
    required this.vehiculo,
    required this.tipo,
    required this.costo,
    required this.estado,
  });

  _ServicioRow copyWith({
    int? id,
    DateTime? fecha,
    String? cliente,
    String? vehiculo,
    String? tipo,
    double? costo,
    String? estado,
  }) {
    return _ServicioRow(
      id: id ?? this.id,
      fecha: fecha ?? this.fecha,
      cliente: cliente ?? this.cliente,
      vehiculo: vehiculo ?? this.vehiculo,
      tipo: tipo ?? this.tipo,
      costo: costo ?? this.costo,
      estado: estado ?? this.estado,
    );
    }
}

class _HeaderText extends StatelessWidget {
  final String text;
  const _HeaderText(this.text);

  @override
  Widget build(BuildContext context) {
    return Text(
      text,
      style: AppTextStyles.body.copyWith(
        fontWeight: FontWeight.w800,
        color: AppColors.textPrimary,
        letterSpacing: 0.2,
      ),
    );
  }
}

class _TipoBadge extends StatelessWidget {
  final String texto;
  const _TipoBadge({required this.texto});

  @override
  Widget build(BuildContext context) {
    Color bg;
    switch (texto) {
      case _ServiciosScreenState.catDiag:
        bg = AppColors.warning.withOpacity(0.2);
        break;
      case _ServiciosScreenState.catMant:
        bg = AppColors.success.withOpacity(0.2);
        break;
      case _ServiciosScreenState.catRep:
        bg = AppColors.secondary.withOpacity(0.15);
        break;
      case _ServiciosScreenState.catProg:
        bg = AppColors.primary.withOpacity(0.18);
        break;
      default:
        bg = AppColors.backgroundVariant;
    }

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(
        color: bg,
        borderRadius: BorderRadius.circular(999),
      ),
      child: Text(
        texto,
        overflow: TextOverflow.ellipsis,
        style: AppTextStyles.body.copyWith(
          color: AppColors.textPrimary,
          fontWeight: FontWeight.w700,
        ),
      ),
    );
  }
}
