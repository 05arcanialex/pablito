// lib/data/local/database_helper.dart
import 'dart:async';
import 'package:flutter/foundation.dart' show kReleaseMode;
import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';
import 'package:sqflite_live/sqflite_live.dart';

class DatabaseHelper {
  DatabaseHelper._();
  static final DatabaseHelper instance = DatabaseHelper._();
  static Database? _db;

  static const _dbName = 'taller_mecanico.db';
  static const _dbVersion = 1;

  // 🚦 BANDERA PARA EVITAR ARRANCAR sqflite_live MÁS DE UNA VEZ
  static bool _liveStarted = false;

  Future<Database> get database async {
    if (_db != null) return _db!;
    _db = await _initDB();
    return _db!;
  }

  Future<Database> _initDB() async {
    final dbPath = await getDatabasesPath();
    final path = join(dbPath, _dbName);

    final db = await openDatabase(
      path,
      version: _dbVersion,
      onConfigure: (db) async {
        // ✅ PRAGMA CON rawQuery (SIN ';'), Y CON TRY/CATCH PARA EVITAR CRASH
        try { await db.rawQuery('PRAGMA foreign_keys = ON'); } catch (_) {}
        try { await db.rawQuery('PRAGMA journal_mode = WAL'); } catch (_) {}
        try { await db.rawQuery('PRAGMA synchronous = NORMAL'); } catch (_) {}
      },
      onCreate: _onCreate,
      onUpgrade: _onUpgrade,
    );

    // 🚀 ARRANCAR SERVIDOR DE INSPECCIÓN SOLO EN DEBUG
    if (!kReleaseMode && !_liveStarted) {
      _liveStarted = await _startSqfliteLiveSafely(db);
    }

    return db;
  }

  /// INTENTA LEVANTAR sqflite_live EN PUERTOS {8888, 8889, 8890}. DEVUELVE TRUE SI ARRANCÓ.
  Future<bool> _startSqfliteLiveSafely(Database db) async {
    final candidatePorts = <int>[8888, 8889, 8890];

    for (final port in candidatePorts) {
      try {
        await db.live(port: port);
        // ignore: avoid_print
        print('✅ SQFLITE_LIVE LEVANTADO EN http://localhost:$port');
        // ignore: avoid_print
        print('💡 SI USAS DISPOSITIVO FÍSICO POR USB: `adb reverse tcp:$port tcp:$port`');
        // ignore: avoid_print
        print('🌐 SI QUIERES ENTRAR DESDE OTRO DISPOSITIVO EN LA MISMA LAN: http://<IP_DE_TU_PC>:$port');
        return true;
      } catch (e) {
        final msg = e.toString();
        final inUse = msg.contains('Address already in use') ||
                      msg.contains('EADDRINUSE') ||
                      msg.contains('in use');
        // ignore: avoid_print
        print('⚠️  NO SE PUDO INICIAR SQFLITE_LIVE EN PUERTO $port: $e');
        if (!inUse) {
          // SI EL ERROR NO ES "PUERTO EN USO", NO INSISTIMOS MÁS
          break;
        }
        // SI ESTÁ OCUPADO, PRUEBA EL SIGUIENTE PUERTO
      }
    }
    // ignore: avoid_print
    print('ℹ️  CONTINUANDO SIN SQFLITE_LIVE (NO HAY PUERTO DISPONIBLE O FALLÓ EL INICIO).');
    return false;
  }

  // =====================================================
  // 🔧 CREACIÓN DE TABLAS (ESPEJO DE TU MYSQL)
  // =====================================================
  Future<void> _onCreate(Database db, int version) async {
    final batch = db.batch();

    batch.execute('''
    CREATE TABLE cargo_empleado(
      cod_cargo_emp INTEGER PRIMARY KEY AUTOINCREMENT,
      descripcion   TEXT NOT NULL
    );
    ''');

    batch.execute('''
    CREATE TABLE persona(
      cod_persona INTEGER PRIMARY KEY AUTOINCREMENT,
      nombre      TEXT NOT NULL,
      apellidos   TEXT NOT NULL,
      telefono    TEXT,
      email       TEXT
    );
    ''');

    batch.execute('''
    CREATE TABLE cliente(
      cod_clinte  INTEGER PRIMARY KEY AUTOINCREMENT,
      cod_persona INTEGER NOT NULL,
      FOREIGN KEY(cod_persona) REFERENCES persona(cod_persona)
        ON UPDATE RESTRICT ON DELETE RESTRICT
    );
    ''');

    batch.execute('''
    CREATE TABLE empleado(
      cod_empleado  INTEGER PRIMARY KEY AUTOINCREMENT,
      cod_persona   INTEGER NOT NULL,
      cod_cargo_emp INTEGER NOT NULL,
      FOREIGN KEY(cod_persona)   REFERENCES persona(cod_persona)
        ON UPDATE RESTRICT ON DELETE RESTRICT,
      FOREIGN KEY(cod_cargo_emp) REFERENCES cargo_empleado(cod_cargo_emp)
        ON UPDATE RESTRICT ON DELETE RESTRICT
    );
    ''');

    batch.execute('''
    CREATE TABLE estado_recibo(
      cod_est_rec   INTEGER PRIMARY KEY AUTOINCREMENT,
      estado_recibo TEXT NOT NULL
    );
    ''');

    batch.execute('''
    CREATE TABLE inventario_vehiculo(
      cod_inv_veh     INTEGER PRIMARY KEY AUTOINCREMENT,
      descripcion_inv TEXT,
      descripcion     TEXT
    );
    ''');

    batch.execute('''
    CREATE TABLE marca_vehiculo(
      cod_marca_veh INTEGER PRIMARY KEY AUTOINCREMENT,
      descripcion   TEXT NOT NULL
    );
    ''');

    batch.execute('''
    CREATE TABLE modelo_vehiculo(
      cod_modelo_veh     INTEGER PRIMARY KEY AUTOINCREMENT,
      anio_modelo        INTEGER,
      descripcion_modelo TEXT
    );
    ''');

    batch.execute('''
    CREATE TABLE vehiculo(
      cod_vehiculo   INTEGER PRIMARY KEY AUTOINCREMENT,
      cod_cliente    INTEGER NOT NULL,
      cod_marca_veh  INTEGER NOT NULL,
      cod_modelo_veh INTEGER NOT NULL,
      kilometraje    INTEGER,
      placas         TEXT NOT NULL,
      numero_serie   TEXT,
      color          TEXT,
      UNIQUE(placas),
      FOREIGN KEY(cod_cliente)    REFERENCES cliente(cod_clinte)
        ON UPDATE RESTRICT ON DELETE RESTRICT,
      FOREIGN KEY(cod_marca_veh)  REFERENCES marca_vehiculo(cod_marca_veh)
        ON UPDATE RESTRICT ON DELETE RESTRICT,
      FOREIGN KEY(cod_modelo_veh) REFERENCES modelo_vehiculo(cod_modelo_veh)
        ON UPDATE RESTRICT ON DELETE RESTRICT
    );
    ''');

    batch.execute('''
    CREATE TABLE recibo_pago(
      cod_recibo_pago    INTEGER PRIMARY KEY AUTOINCREMENT,
      fecha              TEXT NOT NULL,
      total              REAL,
      a_cuenta           REAL,
      saldo              REAL,
      transferencia_pago TEXT,
      cod_cliente        INTEGER NOT NULL,
      cod_empleado       INTEGER NOT NULL,
      cod_est_rec        INTEGER NOT NULL,
      FOREIGN KEY(cod_cliente)  REFERENCES cliente(cod_clinte)
        ON UPDATE RESTRICT ON DELETE RESTRICT,
      FOREIGN KEY(cod_empleado) REFERENCES empleado(cod_empleado)
        ON UPDATE RESTRICT ON DELETE RESTRICT,
      FOREIGN KEY(cod_est_rec)  REFERENCES estado_recibo(cod_est_rec)
        ON UPDATE RESTRICT ON DELETE RESTRICT
    );
    ''');

    batch.execute('''
    CREATE TABLE registro_auxilio_mecanico(
      cod_reg_auxilio   INTEGER PRIMARY KEY AUTOINCREMENT,
      fecha             TEXT NOT NULL,
      ubicacion_cliente TEXT,
      cod_cliente       INTEGER NOT NULL,
      FOREIGN KEY(cod_cliente) REFERENCES cliente(cod_clinte)
        ON UPDATE RESTRICT ON DELETE RESTRICT
    );
    ''');

    batch.execute('''
    CREATE TABLE registro_servicio_taller(
      cod_ser_taller  INTEGER PRIMARY KEY AUTOINCREMENT,
      cod_recibo_pago INTEGER NOT NULL,
      cod_vehiculo    INTEGER NOT NULL,
      cod_empleado    INTEGER NOT NULL,
      fecha_ingreso   TEXT,
      fecha_salida    TEXT,
      ingreso_en_grua INTEGER,
      observaciones   TEXT,
      FOREIGN KEY(cod_recibo_pago) REFERENCES recibo_pago(cod_recibo_pago)
        ON UPDATE RESTRICT ON DELETE RESTRICT,
      FOREIGN KEY(cod_vehiculo)    REFERENCES vehiculo(cod_vehiculo)
        ON UPDATE RESTRICT ON DELETE RESTRICT,
      FOREIGN KEY(cod_empleado)    REFERENCES empleado(cod_empleado)
        ON UPDATE RESTRICT ON DELETE RESTRICT
    );
    ''');

    batch.execute('''
    CREATE TABLE tipo_trabajo(
      cod_tipo_trabajo INTEGER PRIMARY KEY AUTOINCREMENT,
      descripcion      TEXT
    );
    ''');

    batch.execute('''
    CREATE TABLE reg_aux_mec_tipo_trabajo(
      cod_reg_auxilio_tipo INTEGER PRIMARY KEY AUTOINCREMENT,
      cod_reg_auxilio      INTEGER NOT NULL,
      cod_tipo_trabajo     INTEGER NOT NULL,
      detalles             TEXT,
      costo                REAL,
      FOREIGN KEY(cod_reg_auxilio)  REFERENCES registro_auxilio_mecanico(cod_reg_auxilio)
        ON UPDATE RESTRICT ON DELETE RESTRICT,
      FOREIGN KEY(cod_tipo_trabajo) REFERENCES tipo_trabajo(cod_tipo_trabajo)
        ON UPDATE RESTRICT ON DELETE RESTRICT
    );
    ''');

    batch.execute('''
    CREATE TABLE reg_inventario_vehiculo(
      cod_reg_inv_veh INTEGER PRIMARY KEY AUTOINCREMENT,
      cod_inv_veh     INTEGER NOT NULL,
      cod_vehiculo    INTEGER NOT NULL,
      cod_empleado    INTEGER NOT NULL,
      cantidad        INTEGER,
      estado          TEXT,
      FOREIGN KEY(cod_inv_veh)  REFERENCES inventario_vehiculo(cod_inv_veh)
        ON UPDATE RESTRICT ON DELETE RESTRICT,
      FOREIGN KEY(cod_vehiculo) REFERENCES vehiculo(cod_vehiculo)
        ON UPDATE RESTRICT ON DELETE RESTRICT,
      FOREIGN KEY(cod_empleado) REFERENCES empleado(cod_empleado)
        ON UPDATE RESTRICT ON DELETE RESTRICT
    );
    ''');

    batch.execute('''
    CREATE TABLE reg_serv_taller_tipo_trabajo(
      cod_reg_ser_taller_tipo INTEGER PRIMARY KEY AUTOINCREMENT,
      cod_ser_taller          INTEGER NOT NULL,
      cod_tipo_trabajo        INTEGER NOT NULL,
      costo                   REAL,
      detalles                TEXT,
      FOREIGN KEY(cod_ser_taller)   REFERENCES registro_servicio_taller(cod_ser_taller)
        ON UPDATE RESTRICT ON DELETE RESTRICT,
      FOREIGN KEY(cod_tipo_trabajo) REFERENCES tipo_trabajo(cod_tipo_trabajo)
        ON UPDATE RESTRICT ON DELETE RESTRICT
    );
    ''');

    batch.execute('''
    CREATE TABLE usuario(
      cod_usuario    INTEGER PRIMARY KEY AUTOINCREMENT,
      nombre_usu     TEXT NOT NULL,
      contrasena_usu TEXT NOT NULL,
      correo         TEXT NOT NULL UNIQUE,
      nivel_acceso   TEXT NOT NULL,
      estado         TEXT,
      cod_empleado   INTEGER,
      FOREIGN KEY(cod_empleado) REFERENCES empleado(cod_empleado)
        ON UPDATE RESTRICT ON DELETE RESTRICT
    );
    ''');

    // SEED BÁSICO
    batch.insert('estado_recibo', {'estado_recibo': 'PENDIENTE'});
    batch.insert('estado_recibo', {'estado_recibo': 'PAGADO'});
    batch.insert('estado_recibo', {'estado_recibo': 'ANULADO'});

    await batch.commit(noResult: true);
  }

  Future<void> _onUpgrade(Database db, int oldVersion, int newVersion) async {
    // AQUI VAN MIGRACIONES CUANDO SUBAS _dbVersion
  }

  // =====================================================
  // 🧰 HELPERS
  // =====================================================
  Future<T> tx<T>(Future<T> Function(Transaction) action) async {
    final db = await database;
    return db.transaction(action);
  }

  Future<int> rawInsert(String sql, [List<Object?>? args]) async {
    final db = await database;
    return db.rawInsert(sql, args);
  }

  Future<int> rawUpdate(String sql, [List<Object?>? args]) async {
    final db = await database;
    return db.rawUpdate(sql, args);
  }

  Future<int> rawDelete(String sql, [List<Object?>? args]) async {
    final db = await database;
    return db.rawDelete(sql, args);
  }

  Future<List<Map<String, Object?>>> rawQuery(String sql, [List<Object?>? args]) async {
    final db = await database;
    return db.rawQuery(sql, args);
  }

  // 🔄 RESET RÁPIDO (SOLO DEV)
  static Future<void> resetDevDB() async {
    final dbPath = await getDatabasesPath();
    final path = join(dbPath, _dbName);
    await deleteDatabase(path);
    _db = null;
    await instance.database;
  }
}
