// lib/main.dart
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

// 🧠 ESTADOS (SIN SERVICES)
import 'viewmodels/dashboard_viewmodel.dart';

// 🎨 TEMA/CONSTANTES
import 'utils/constants.dart';

// 🗄️ BASE DE DATOS LOCAL (SQFLITE)
import '../models/database_helper.dart';

// 🖥️ VISTAS
import 'screens/auth/login_screen.dart';
import 'screens/dashboard/dashboard_screen.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // 🔹 Inicializa la base de datos local (activa FKs, etc.)
  try {
    await DatabaseHelper.instance.database;
  } catch (e) {
    debugPrint('ERROR AL ABRIR/CREAR LA BD: $e');
  }

  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => DashboardViewModel()),
      ],
      child: MaterialApp(
        debugShowCheckedModeBanner: false,
        title: AppStrings.appName,
        theme: ThemeData(
          useMaterial3: true,
          primaryColor: AppColors.primary,
          scaffoldBackgroundColor: AppColors.background,
          appBarTheme: const AppBarTheme(
            backgroundColor: AppColors.primary,
            foregroundColor: Colors.white,
            centerTitle: true,
            elevation: 2,
            titleTextStyle: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
              color: Colors.white,
            ),
          ),
          elevatedButtonTheme: ElevatedButtonThemeData(
            style: ElevatedButton.styleFrom(
              backgroundColor: AppColors.primary,
              foregroundColor: Colors.white,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(AppRadius.medium),
              ),
              padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 24),
            ),
          ),
          inputDecorationTheme: InputDecorationTheme(
            filled: true,
            fillColor: Colors.white,
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(AppRadius.medium),
              borderSide: const BorderSide(color: AppColors.textSecondary),
            ),
            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(AppRadius.medium),
              borderSide: const BorderSide(color: AppColors.primary, width: 2),
            ),
            labelStyle: const TextStyle(color: AppColors.textSecondary),
          ),
          snackBarTheme: const SnackBarThemeData(
            backgroundColor: AppColors.secondary,
            contentTextStyle: TextStyle(color: Colors.white),
          ),
        ),
        home: const Root(),
      ),
    );
  }
}

/// =====================================
/// 🌐 ROOT: CONTROL DE SESIÓN SIN AuthState
/// =====================================
class Root extends StatefulWidget {
  const Root({super.key});

  @override
  State<Root> createState() => _RootState();
}

class _RootState extends State<Root> {
  bool _loggedIn = false;

  void _handleLoggedIn() {
    setState(() => _loggedIn = true);
  }

  void _handleSOS() {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text(Messages.sosEnviado)),
    );
  }

  @override
  Widget build(BuildContext context) {
    if (_loggedIn) return const DashboardScreen();

    // 🚪 Si no está logueado → Login con botón SOS
    return LoginScreen(
      onLoggedIn: _handleLoggedIn,
      onPressSOS: _handleSOS,
    );
  }
}
